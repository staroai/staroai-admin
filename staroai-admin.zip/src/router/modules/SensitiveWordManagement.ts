// import { $t } from "@/plugins/i18n";
const { VITE_HIDE_HOME } = import.meta.env;
const Layout = () => import("@/layout/index.vue");

export default {
  path: "/",
  name: "SensitiveWordManagement",
  component: Layout,
  redirect: "/SensitiveWordManagement",
  meta: {
    icon: "ep:home-filled",
    title: "敏感词管理",
    rank: 0
  },
  children: [
    {
      path: "/SensitiveWordManagement",
      name: "SensitiveWordManagement",
      component: () => import("@/views/SensitiveWordManagement/index.vue"),
      meta: {
        title: "敏感词管理",
        showLink: VITE_HIDE_HOME === "true" ? false : true
      }
    }
  ]
} satisfies RouteConfigsTable;
